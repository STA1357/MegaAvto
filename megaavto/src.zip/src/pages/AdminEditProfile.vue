<!-- @format -->

<template>
  <div>
    <EditProfile />
  </div>
</template>

<script>
import EditProfile from '../components/EditProfile';
export default {
  name: 'AdminProfile',
  components: {
    EditProfile,
  },
};
</script>

<style></style>
