<template>
    <div class="thirdBlock">
        <div class="row d-flex justify-center align-center" style="height: 100%">
          <div class="col-md-4 col-12">
            <div class="block">
              <h3 class="pt-3">Стандарт</h3>
              <p>3 запроса в день</p>
              <hr>
              <h1>99$</h1>
              <p class="pb-5">За месяц</p>
            </div>
          </div>
          <div class="col-md-4 col-12">
            <div class="block">
              <h3 class="pt-3">Выгодный</h3>
              <p>3 запроса в день</p>
              <hr>
              <h1>199$</h1>
              <p class="pb-5">За месяц</p>
            </div>
          </div>
          <div class="col-md-4 col-12">
            <div class="block">
              <h3 class="pt-3">Супер!</h3>
              <p>3 запроса в день</p>
              <hr>
              <h1>299$</h1>
              <p class="pb-5">За месяц</p>
            </div>
          </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "ThirdBlock"
    }
</script>

<style scoped lang="scss">
.thirdBlock{
  background: linear-gradient(180deg, #F2994A 0%, #FF7A7A 100%)!important;
  margin-top: 70px;
  height: 385px;
}
.block{
  background-color: white;
  margin: 0 40px;
  padding: 35px;
  border-radius: 35px;
}
h3{
  font-family: Roboto;
  font-style: normal;
  font-weight: normal;
  font-size: 32px;
  line-height: 37px;
  /* identical to box height */

  letter-spacing: 0.5px;

  color: #000000;
}
h1{
  font-family: Roboto;
  font-style: normal;
  font-weight: normal;
  font-size: 42px;
  line-height: 37px;
  /* identical to box height */

  letter-spacing: 0.5px;

  color: #000000;
}
</style>
