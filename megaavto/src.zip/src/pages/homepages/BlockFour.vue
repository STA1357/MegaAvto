<template>
    <div class="blockFour">
      <div class="row d-flex justify-center align-center" style="height: 100%">
        <div class="col-md-12 col-12">
          <h1>Отзывы</h1>
        </div>
        <div class="col-md-4 col-12">
          <div class="review-block">
            <div class="maga">
              <img src="../../assets/Ellipse.png" alt="">
            </div>
            <h4 class="name">Ереван</h4>
            <p>Супер Сервис и прочий текс который мы можем вместить для отзывов это вот такой лимит</p>
          </div>
        </div>
        <div class="col-md-4 col-12">
          <div class="review-block">
            <div class="maga">
              <img src="../../assets/Ellipse.png" alt="">
            </div>
            <h4 class="name">Ереван</h4>
            <p>Супер Сервис и прочий текс который мы можем вместить для отзывов это вот такой лимит</p>
          </div>
        </div>
        <div class="col-md-4 col-12">
          <div class="review-block">
            <div class="maga">
              <img src="../../assets/Ellipse.png" alt="">
            </div>
            <h4 class="name">Ереван</h4>
            <p>Супер Сервис и прочий текс который мы можем вместить для отзывов это вот такой лимит</p>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "BlockFour"
    }
</script>

<style scoped lang="scss">
.blockFour{
  background-color: white;
  height: 600px;
}
.maga img{
  border-top: 5px solid #F2994A;
  border-bottom: 5px solid #FF7A7A;
  border-left: 5px solid #F2994A;
  border-right: 5px solid #FF7A7A;
  border-radius: 50%;
  padding: 25px;
  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
}
.maga{
  padding-bottom: 15px;
}
.review-block{
  margin-bottom: 40px;
}
h1{
  font-family: Roboto;
  font-style: normal;
  font-weight: normal;
  font-size: 45px;
  line-height: 53px;
  /* identical to box height */


  color: #081F32;
  margin-bottom: -40px;
}
h4{
  font-family: Roboto;
  font-style: normal;
  font-weight: normal;
  font-size: 28px;
  line-height: 33px;

  color: #000000;
}
p{
  font-family: Roboto;
  font-style: normal;
  font-weight: normal;
  font-size: 18px;
  line-height: 21px;

  color: #000000;
  padding-top: 15px;
}

</style>
