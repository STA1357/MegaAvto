<template>
    <div>
      <p>adress</p>
      <p>phone</p>
    </div>
</template>

<script>
    export default {
        name: "OurContacts"
    }
</script>

<style scoped>

</style>
