<template>
  <div>About</div>
</template>

<script>
export default {
  components: {},
};
</script>

<style></style>
